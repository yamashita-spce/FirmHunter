<?
include "/htdocs/phplib/xnode.php";
?>
<form id="mainform" onsubmit="return false;">
<div class="orangebox">
	<h1><?echo i18n("Forbidden WEB Access");?></h1>
	<div class="emptyline"></div>
	<div class="info">
	<center>
	<?echo i18n("Access to this Web Site is not allowed from this computer. This page is blocked by Website Filter.");?>
	</center>
	</div>
	<div class="emptyline"></div>
</div>
</form>
