<?
include "/htdocs/phplib/trace.php";

$G_SHELL_PATH = "/var/run";
$G_GENA_NODEBASE= "/runtime/services/upnp";

$G_IGD = "urn:schemas-upnp-org:device:InternetGatewayDevice:1";
$G_WFA = "urn:schemas-wifialliance-org:device:WFADevice:1";
?>
