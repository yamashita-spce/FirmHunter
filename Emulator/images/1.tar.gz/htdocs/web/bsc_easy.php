HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "bsc_easy";
$TEMP_MYGROUP   = "";
$TEMP_STYLE		= "simple";
include "/htdocs/webinc/templates.php";
?>
