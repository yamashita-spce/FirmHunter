HTTP/1.1 200 OK

<?
/*necessary and basic definition */
$TEMP_MYNAME    = "adv_qos";
$TEMP_MYGROUP   = "advanced";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
