HTTP/1.1 200 OK

<?
/* necessary and basic definition */
$TEMP_MYNAME    = "tools_ddns";
$TEMP_MYGROUP   = "tools";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
