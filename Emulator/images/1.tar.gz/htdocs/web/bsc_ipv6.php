HTTP/1.1 200 OK

<?
/*necessary and basic definition */
$TEMP_MYNAME    = "bsc_ipv6";
$TEMP_MYGROUP   = "basic";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
