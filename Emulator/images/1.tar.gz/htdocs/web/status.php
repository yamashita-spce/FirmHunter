<?
include "/htdocs/web/st_device.php";
?>
