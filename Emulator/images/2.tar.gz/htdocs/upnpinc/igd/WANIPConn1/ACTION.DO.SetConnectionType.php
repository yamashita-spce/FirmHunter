<? $_GLOBALS["errorCode"]=501; ?>
