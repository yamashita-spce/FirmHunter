HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "spt_menu";
$TEMP_MYGROUP   = "support";
$TEMP_STYLE	= "support";
include "/htdocs/webinc/templates.php";
?>
