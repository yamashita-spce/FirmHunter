HTTP/1.1 200 OK

<?
/*necessary and basic definition */
$TEMP_MYNAME    = "adv_ipv6";
$TEMP_MYGROUP   = "advanced";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
